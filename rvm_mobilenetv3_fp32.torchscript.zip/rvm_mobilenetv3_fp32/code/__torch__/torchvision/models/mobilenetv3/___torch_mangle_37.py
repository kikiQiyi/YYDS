class SqueezeExcitation(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  fc1 : __torch__.torch.nn.modules.conv.___torch_mangle_35.Conv2d
  relu : __torch__.torch.nn.modules.activation.ReLU
  fc2 : __torch__.torch.nn.modules.conv.___torch_mangle_36.Conv2d
  def forward(self: __torch__.torchvision.models.mobilenetv3.___torch_mangle_37.SqueezeExcitation,
    input: Tensor) -> Tensor:
    scale = (self)._scale(input, True, )
    return torch.mul(scale, input)
  def _scale(self: __torch__.torchvision.models.mobilenetv3.___torch_mangle_37.SqueezeExcitation,
    input: Tensor,
    inplace: bool) -> Tensor:
    _0 = __torch__.torch.nn.functional.adaptive_avg_pool2d
    _1 = __torch__.torch.nn.functional.hardsigmoid
    scale = _0(input, [1, 1], )
    scale0 = (self.fc1).forward(scale, )
    scale1 = (self.relu).forward(scale0, )
    scale2 = (self.fc2).forward(scale1, )
    return _1(scale2, inplace, )
