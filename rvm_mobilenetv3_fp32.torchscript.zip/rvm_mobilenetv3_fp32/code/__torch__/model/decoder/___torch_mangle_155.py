class Projection(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_154.Conv2d
  def forward(self: __torch__.model.decoder.___torch_mangle_155.Projection,
    x: Tensor) -> Tensor:
    if torch.eq(torch.dim(x), 5):
      _0 = (self).forward_time_series(x, )
    else:
      _0 = (self).forward_single_frame(x, )
    return _0
  def forward_time_series(self: __torch__.model.decoder.___torch_mangle_155.Projection,
    x: Tensor) -> Tensor:
    B, T, _1, H, W, = torch.size(x)
    _2 = (self.conv).forward(torch.flatten(x, 0, 1), )
    return torch.reshape(_2, [B, T, -1, H, W])
  def forward_single_frame(self: __torch__.model.decoder.___torch_mangle_155.Projection,
    x: Tensor) -> Tensor:
    return (self.conv).forward(x, )
