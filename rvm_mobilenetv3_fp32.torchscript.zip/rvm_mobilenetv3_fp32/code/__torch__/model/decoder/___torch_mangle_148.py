class UpsamplingBlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  out_channels : int
  upsample : __torch__.torch.nn.modules.upsampling.Upsample
  conv : __torch__.torch.nn.modules.container.___torch_mangle_142.Sequential
  gru : __torch__.model.decoder.___torch_mangle_147.ConvGRU
  def forward(self: __torch__.model.decoder.___torch_mangle_148.UpsamplingBlock,
    x: Tensor,
    f: Tensor,
    s: Tensor,
    r: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    if torch.eq(torch.dim(x), 5):
      _1 = (self).forward_time_series(x, f, s, r, )
      _0 = _1
    else:
      _2 = (self).forward_single_frame(x, f, s, r, )
      _0 = _2
    return _0
  def forward_time_series(self: __torch__.model.decoder.___torch_mangle_148.UpsamplingBlock,
    x: Tensor,
    f: Tensor,
    s: Tensor,
    r: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    B, T, _3, H, W, = torch.size(s)
    x0 = torch.flatten(x, 0, 1)
    f0 = torch.flatten(f, 0, 1)
    s0 = torch.flatten(s, 0, 1)
    x1 = (self.upsample).forward(x0, )
    _4 = torch.slice(x1, 0, 0, 9223372036854775807, 1)
    _5 = torch.slice(_4, 1, 0, 9223372036854775807, 1)
    x2 = torch.slice(torch.slice(_5, 2, 0, H, 1), 3, 0, W, 1)
    x3 = torch.cat([x2, f0, s0], 1)
    x4 = (self.conv).forward(x3, )
    x5 = torch.reshape(x4, [B, T, -1, H, W])
    _6 = torch.floordiv(self.out_channels, 2)
    a, b, = torch.split(x5, _6, 2)
    b0, r0, = (self.gru).forward(b, r, )
    x6 = torch.cat([a, b0], 2)
    return (x6, r0)
  def forward_single_frame(self: __torch__.model.decoder.___torch_mangle_148.UpsamplingBlock,
    x: Tensor,
    f: Tensor,
    s: Tensor,
    r: Optional[Tensor]) -> Tuple[Tensor, Tensor]:
    x7 = (self.upsample).forward(x, )
    _7 = torch.slice(x7, 0, 0, 9223372036854775807, 1)
    _8 = torch.slice(_7, 1, 0, 9223372036854775807, 1)
    _9 = torch.slice(_8, 2, 0, torch.size(s, 2), 1)
    x8 = torch.slice(_9, 3, 0, torch.size(s, 3), 1)
    x9 = torch.cat([x8, f, s], 1)
    x10 = (self.conv).forward(x9, )
    _10 = torch.floordiv(self.out_channels, 2)
    a, b, = torch.split(x10, _10, 1)
    b1, r1, = (self.gru).forward(b, r, )
    x11 = torch.cat([a, b1], 1)
    return (x11, r1)
