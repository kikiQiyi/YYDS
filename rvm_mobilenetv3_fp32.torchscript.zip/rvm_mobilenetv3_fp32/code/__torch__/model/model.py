class MattingNetwork(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  backbone : __torch__.model.mobilenetv3.MobileNetV3LargeEncoder
  aspp : __torch__.model.lraspp.LRASPP
  decoder : __torch__.model.decoder.RecurrentDecoder
  project_mat : __torch__.model.decoder.Projection
  project_seg : __torch__.model.decoder.___torch_mangle_155.Projection
  refiner : __torch__.model.deep_guided_filter.DeepGuidedFilterRefiner
  def forward(self: __torch__.model.model.MattingNetwork,
    src: Tensor,
    r1: Optional[Tensor]=None,
    r2: Optional[Tensor]=None,
    r3: Optional[Tensor]=None,
    r4: Optional[Tensor]=None,
    downsample_ratio: float=1.,
    segmentation_pass: bool=False) -> List[Tensor]:
    if torch.ne(downsample_ratio, 1):
      src_sm0 = (self)._interpolate(src, downsample_ratio, )
      src_sm = src_sm0
    else:
      src_sm = src
    f1, f2, f3, f4, = (self.backbone).forward(src_sm, )
    f40 = (self.aspp).forward(f4, )
    _0 = (self.decoder).forward(src_sm, f1, f2, f3, f40, r1, r2, r3, r4, )
    hid, _1, _2, _3, _4, = _0
    if torch.__not__(segmentation_pass):
      _6 = torch.split((self.project_mat).forward(hid, ), [3, 1], -3)
      fgr_residual, pha, = _6
      if torch.ne(downsample_ratio, 1):
        _7 = (self.refiner).forward(src, src_sm, fgr_residual, pha, hid, )
        fgr_residual1, pha1, = _7
        fgr_residual0, pha0 = fgr_residual1, pha1
      else:
        fgr_residual0, pha0 = fgr_residual, pha
      fgr = torch.add(fgr_residual0, src, alpha=1)
      fgr0 = torch.clamp(fgr, 0., 1.)
      pha2 = torch.clamp(pha0, 0., 1.)
      _5 = [fgr0, pha2, _1, _2, _3, _4]
    else:
      seg = (self.project_seg).forward(hid, )
      _5 = [seg, _1, _2, _3, _4]
    return _5
  def _interpolate(self: __torch__.model.model.MattingNetwork,
    x: Tensor,
    scale_factor: float) -> Tensor:
    _8 = __torch__.torch.nn.functional.___torch_mangle_160.interpolate
    if torch.eq(torch.dim(x), 5):
      _9 = torch.slice(torch.size(x), 0, 2, 1)
      B, T, = _9
      x1 = _8(torch.flatten(x, 0, 1), None, scale_factor, "bilinear", False, False, )
      _10 = [B, T, torch.size(x1, 1), torch.size(x1, 2), torch.size(x1, 3)]
      x0 = torch.reshape(x1, _10)
    else:
      x2 = _8(x, None, scale_factor, "bilinear", False, False, )
      x0 = x2
    return x0
