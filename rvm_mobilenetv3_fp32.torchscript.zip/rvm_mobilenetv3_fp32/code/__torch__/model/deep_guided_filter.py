class DeepGuidedFilterRefiner(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  box_filter : __torch__.torch.nn.modules.conv.___torch_mangle_156.Conv2d
  conv : __torch__.torch.nn.modules.container.___torch_mangle_158.Sequential
  def forward(self: __torch__.model.deep_guided_filter.DeepGuidedFilterRefiner,
    fine_src: Tensor,
    base_src: Tensor,
    base_fgr: Tensor,
    base_pha: Tensor,
    base_hid: Tensor) -> Tuple[Tensor, Tensor]:
    if torch.eq(torch.dim(fine_src), 5):
      _1 = (self).forward_time_series(fine_src, base_src, base_fgr, base_pha, base_hid, )
      _0 = _1
    else:
      _2 = (self).forward_single_frame(fine_src, base_src, base_fgr, base_pha, base_hid, )
      _0 = _2
    return _0
  def forward_time_series(self: __torch__.model.deep_guided_filter.DeepGuidedFilterRefiner,
    fine_src: Tensor,
    base_src: Tensor,
    base_fgr: Tensor,
    base_pha: Tensor,
    base_hid: Tensor) -> Tuple[Tensor, Tensor]:
    B, T, _3, H, W, = torch.size(fine_src)
    _4 = (self).forward_single_frame(torch.flatten(fine_src, 0, 1), torch.flatten(base_src, 0, 1), torch.flatten(base_fgr, 0, 1), torch.flatten(base_pha, 0, 1), torch.flatten(base_hid, 0, 1), )
    fgr, pha, = _4
    fgr0 = torch.reshape(fgr, [B, T, 3, H, W])
    pha0 = torch.reshape(pha, [B, T, 1, H, W])
    return (fgr0, pha0)
  def forward_single_frame(self: __torch__.model.deep_guided_filter.DeepGuidedFilterRefiner,
    fine_src: Tensor,
    base_src: Tensor,
    base_fgr: Tensor,
    base_pha: Tensor,
    base_hid: Tensor) -> Tuple[Tensor, Tensor]:
    _5 = __torch__.torch.nn.functional.___torch_mangle_159.interpolate
    _6 = torch.slice(torch.size(fine_src), 2, 9223372036854775807, 1)
    H, W, = _6
    _7 = torch.mean(fine_src, [1], True, dtype=None)
    fine_x = torch.cat([fine_src, _7], 1)
    _8 = torch.mean(base_src, [1], True, dtype=None)
    base_x = torch.cat([base_src, _8], 1)
    base_y = torch.cat([base_fgr, base_pha], 1)
    mean_x = (self.box_filter).forward(base_x, )
    mean_y = (self.box_filter).forward(base_y, )
    _9 = (self.box_filter).forward(torch.mul(base_x, base_y), )
    cov_xy = torch.sub(_9, torch.mul(mean_x, mean_y), alpha=1)
    _10 = (self.box_filter).forward(torch.mul(base_x, base_x), )
    var_x = torch.sub(_10, torch.mul(mean_x, mean_x), alpha=1)
    _11 = self.conv
    _12 = torch.cat([cov_xy, var_x, base_hid], 1)
    A = (_11).forward(_12, )
    b = torch.sub(mean_y, torch.mul(A, mean_x), alpha=1)
    A0 = _5(A, [H, W], None, "bilinear", False, None, )
    b0 = _5(b, [H, W], None, "bilinear", False, None, )
    out = torch.add(torch.mul(A0, fine_x), b0, alpha=1)
    fgr, pha, = torch.split(out, [3, 1], 1)
    return (fgr, pha)
