def batch_norm(input: Tensor,
    running_mean: Optional[Tensor],
    running_var: Optional[Tensor],
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    training: bool=False,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _0 = __torch__.torch.nn.functional._verify_batch_size
  if training:
    _1 = _0(torch.size(input), )
  else:
    pass
  _2 = torch.batch_norm(input, weight, bias, running_mean, running_var, training, momentum, eps, True)
  return _2
def hardswish(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    _3 = torch.hardswish_(input)
  else:
    _3 = torch.hardswish(input)
  return _3
def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def adaptive_avg_pool2d(input: Tensor,
    output_size: List[int]) -> Tensor:
  _4 = torch.gt(torch.len(torch.size(input)), torch.len(output_size))
  if _4:
    pass
  else:
    ops.prim.RaiseException("AssertionError: ")
  _5 = torch.adaptive_avg_pool2d(input, output_size)
  return _5
def hardsigmoid(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    _6 = torch.hardsigmoid_(input)
  else:
    _6 = torch.hardsigmoid(input)
  return _6
def adaptive_avg_pool3d(input: Tensor,
    output_size: List[int]) -> Tensor:
  _7 = torch.gt(torch.len(torch.size(input)), torch.len(output_size))
  if _7:
    pass
  else:
    ops.prim.RaiseException("AssertionError: ")
  _8 = torch.adaptive_avg_pool3d(input, output_size)
  return _8
def _verify_batch_size(size: List[int]) -> None:
  _9 = "Expected more than 1 value per channel when training, got input size {}"
  size_prods = size[0]
  size_prods0 = size_prods
  for i in range(torch.sub(torch.len(size), 2)):
    size_prods1 = torch.mul(size_prods0, size[torch.add(i, 2)])
    size_prods0 = size_prods1
  if torch.eq(size_prods0, 1):
    ops.prim.RaiseException(torch.format(_9, size))
  else:
    pass
  return None
