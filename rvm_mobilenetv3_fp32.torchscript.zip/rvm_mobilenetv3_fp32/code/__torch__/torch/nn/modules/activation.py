class Hardswish(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : None
  inplace : Final[bool] = True
  def forward(self: __torch__.torch.nn.modules.activation.Hardswish,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.hardswish
    return _0(input, True, )
class ReLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : None
  inplace : Final[bool] = True
  def forward(self: __torch__.torch.nn.modules.activation.ReLU,
    input: Tensor) -> Tensor:
    _1 = __torch__.torch.nn.functional.relu(input, True, )
    return _1
class Sigmoid(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.Sigmoid,
    input: Tensor) -> Tensor:
    return torch.sigmoid(input)
class Tanh(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.Tanh,
    input: Tensor) -> Tensor:
    return torch.tanh(input)
