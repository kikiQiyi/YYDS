class Upsample(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : None
  name : Final[str] = "Upsample"
  align_corners : Final[bool] = False
  mode : Final[str] = "bilinear"
  size : Final[None] = None
  scale_factor : Final[float] = 2.
  def forward(self: __torch__.torch.nn.modules.upsampling.Upsample,
    input: Tensor) -> Tensor:
    _0 = __torch__.torch.nn.functional.___torch_mangle_160.interpolate
    _1 = _0(input, None, 2., "bilinear", False, None, )
    return _1
